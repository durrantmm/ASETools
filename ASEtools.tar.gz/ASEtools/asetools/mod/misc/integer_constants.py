"""
AUTHOR: Matt Durrant

Integer constants to be used throughout asetools.

This can be added to later.
"""

BONF_MAX_PVAL = 1.0
